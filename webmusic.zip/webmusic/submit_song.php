<?php
// Database connection
$servername = "localhost"; // Change this if your MySQL server is on a different host
$username = "root"; // Change this to your MySQL username
$password = "12345678"; // Change this to your MySQL password
$database = "song"; // Change this to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$song_name = $_POST['song_name'];
$singer_name = $_POST['singer_name'];
$song_link = $_POST['song_link'];
$num_likes = $_POST['num_likes'];

// Insert data into database
$sql = "INSERT INTO hits (song_name, singer_name, song_link, num_likes) VALUES ('$song_name', '$singer_name', '$song_link', '$num_likes')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
